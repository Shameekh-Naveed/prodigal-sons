export enum TripSort {
	PRICE_ASC = "price-asc",
	PRICE_DEC = "price-dec",

	DEPARTURE_ASC = "departure-asc",
	DEPARTURE_DEC = "departure-dec",

	CREATED_DEC = "created-dec"
}
