export enum PaymentStatus {
	APPROVED = "approved",
	PENDING = "pending",
	BLOCKED = "failed"
}
