export enum Role {
	ADMIN = "admin",
	USER = "user"
}

export enum Status {
	PENDING = "pending",
	APPROVED = "approved",
	BLOCKED = "blocked"
}
