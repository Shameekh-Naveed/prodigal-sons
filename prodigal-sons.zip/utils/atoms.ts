import { atom } from "jotai"

export const LangAtom = atom("en")

export const LoggedInAtom = atom(false)

export const UserAtom = atom(null)
